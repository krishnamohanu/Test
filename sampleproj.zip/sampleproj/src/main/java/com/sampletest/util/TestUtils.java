package com.sampletest.util;

public class TestUtils {
	
	public static String camleCase(String _str) {
		String input = _str.toLowerCase();
	    StringBuilder sb = new StringBuilder();
	    final char delim = '_';
	    char value;
	    boolean capitalize = false;
	    for (int i=0; i<input.length(); ++i) {
	        value = input.charAt(i);
	        if (value == delim) {
	            capitalize = true;
	        }
	        else if (capitalize) {
	            sb.append(Character.toUpperCase(value));
	            capitalize = false;
	        }
	        else {
	            sb.append(value);
	        }
	    }

	    return sb.toString();
	}
}
